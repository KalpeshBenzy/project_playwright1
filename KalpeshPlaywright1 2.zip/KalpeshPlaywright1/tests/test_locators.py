from playwright.sync_api import expect


# def test_locators_get_by_role(page):
#     page.goto("https://demowebshop.tricentis.com/")
#     page.get_by_role("link",name="Log in").click()
#     page.get_by_role("textbox",name="Email").fill("abc@gmail.com")
#     page.get_by_role("textbox",name="password").fill("abc123")
#     page.get_by_role("button",name="Log in").click()
    
# def test_get_by_text(page):
#     page.goto("https://www.facebook.com")
#     login_to_facebook_text = page.get_by_text("Log in to Facebook")
#     expect(login_to_facebook_text).to_be_visible()
#     forgot_password_button = page.get_by_text("Forgotten password")
#     forgot_password_button.click()
    
#page.get_by_label()

# def test_get_by_label(page):
#     page.goto("https://demowebshop.tricentis.com/")
#     page.get_by_text("Register").click()
#     #page.get_by_role("radio", name = "female").check()
#     page.get_by_label("Male").nth(1).check()
#     page.get_by_label("First name:").fill("shincy")
#     page.get_by_label("Last name:").fill("Mathew")
#     page.get_by_label("Email:").fill("shincy.rose@benzyinfotech.com")
#     page.get_by_label("Password:").nth(0).fill("Benzy")
#     page.get_by_label("Confirm password:").fill("Benzy")
#     page.get_by_role("button", name ="Register").click()
#=======================================================================================
#page.get_by_placeholder

# def test_get_by_placeholder(page):
#     page.goto("https://www.amazon.in/")
#     page.wait_for_timeout(5000)
#     page.get_by_placeholder("Search Amazon.in").fill("mobiles")
#     page.wait_for_timeout(5000)
#     page.keyboard.press("Enter")
#     page.wait_for_timeout(5000)

#=======================================================================================

#only images

# def test_get_by_alt_test(page):
#     page.goto("https://demowebshop.tricentis.com/")
#     logo = page.get_by_alt_text("Tricentis Demo Web Shop")
#     expect(logo).to_be_visible()

#=======================================================================================

#page.get_by_title() to locate an element by its title attributes

def test_get_by_title(page):
    page.goto("https://demowebshop.tricentis.com/")
    logo = page.get_by_title("Tricentis Demo Web Shop")
    logo.click()
    page.wait_for_timeout(5000)
    






